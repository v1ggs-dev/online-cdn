@echo off
setlocal

rem ============================================================
rem  Copies everything in this batch file's folder to:
rem      <Desktop>\OS practical exam
rem  Works on any Windows user account (no hard-coded user name).
rem ============================================================

rem --- Source = folder where this .bat file lives ---
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"

rem --- Find the real Desktop (handles OneDrive / redirected Desktops) ---
set "DESKTOP="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Desktop 2^>nul ^| find "REG_"') do set "DESKTOP=%%B"
if defined DESKTOP call set "DESKTOP=%DESKTOP%"
if not defined DESKTOP set "DESKTOP=%USERPROFILE%\Desktop"
if not exist "%DESKTOP%\" set "DESKTOP=%USERPROFILE%\Desktop"

set "DEST=%DESKTOP%\OS practical exam"

rem --- Copy all files and sub-folders (skip this .bat and the destination itself) ---
robocopy "%SRC%" "%DEST%" /E /R:1 /W:1 /XF "%~nx0" /XD "%DEST%" "%SRC%\TCS" /NFL /NDL /NJH /NJS /NP >nul 2>&1

endlocal
exit
