#include <stdio.h>
#include <stdlib.h>

int req[] = {98, 183, 37, 122, 14, 124, 65, 67}, n = 8;   /* disk requests */
int start = 53;                                            /* initial head position */

/* Part A: FCFS - serve requests in the order they arrive */
void fcfs() {
    printf("--- Part A: FCFS Disk Scheduling ---\n");
    int head = start, total = 0;
    for (int i = 0; i < n; i++) {
        int move = abs(req[i] - head);
        printf("%d -> %d  (move %d)\n", head, req[i], move);
        total += move;
        head = req[i];
    }
    printf("Total head movement = %d\n", total);
}

/* Part B: SSTF - always serve the nearest pending request */
void sstf() {
    printf("--- Part B: SSTF Disk Scheduling ---\n");
    int done[8] = {0}, head = start, total = 0;
    for (int k = 0; k < n; k++) {
        int pick = -1;
        for (int i = 0; i < n; i++)
            if (!done[i] && (pick == -1 || abs(req[i] - head) < abs(req[pick] - head)))
                pick = i;
        int move = abs(req[pick] - head);
        printf("%d -> %d  (move %d)\n", head, req[pick], move);
        total += move;
        head = req[pick];
        done[pick] = 1;
    }
    printf("Total head movement = %d\n", total);
}

int main() {
    fcfs();
    printf("\n");
    sstf();
    return 0;
}
