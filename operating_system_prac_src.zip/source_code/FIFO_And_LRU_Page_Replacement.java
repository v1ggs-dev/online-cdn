public class FIFO_And_LRU_Page_Replacement {
    static int[] ref = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};   // page reference string
    static int f = 3;                                              // number of frames

    static void show(int p, int[] fr, boolean hit) {
        System.out.println("Page " + p + " -> " + fr[0] + " " + fr[1] + " " + fr[2]
                + (hit ? "  (hit)" : "  (fault)"));
    }

    // Part A: FIFO - replace the page that came in first
    static void fifo() {
        System.out.println("--- Part A: FIFO Page Replacement ---");
        int[] fr = {-1, -1, -1};
        int next = 0, faults = 0;
        for (int p : ref) {
            boolean hit = false;
            for (int x : fr) if (x == p) hit = true;
            if (!hit) { fr[next] = p; next = (next + 1) % f; faults++; }
            show(p, fr, hit);
        }
        System.out.println("Total page faults = " + faults);
    }

    // Part B: LRU - replace the page not used for the longest time
    static void lru() {
        System.out.println("--- Part B: LRU Page Replacement ---");
        int[] fr = {-1, -1, -1}, last = new int[f];
        int faults = 0;
        for (int t = 0; t < ref.length; t++) {
            int p = ref[t], hit = -1;
            for (int i = 0; i < f; i++) if (fr[i] == p) hit = i;
            if (hit >= 0) last[hit] = t;
            else {
                int v = 0;
                for (int i = 0; i < f; i++) {
                    if (fr[i] == -1) { v = i; break; }
                    if (last[i] < last[v]) v = i;
                }
                fr[v] = p; last[v] = t; faults++;
            }
            show(p, fr, hit >= 0);
        }
        System.out.println("Total page faults = " + faults);
    }

    public static void main(String[] args) {
        fifo();
        System.out.println();
        lru();
    }
}
