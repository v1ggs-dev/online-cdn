public class SJF_And_Priority_Scheduling {
    // Part A: non-preemptive SJF (all processes arrive at time 0)
    static void sjf() {
        System.out.println("--- Part A: Shortest Job First ---");
        int[] id = {1, 2, 3, 4}, bt = {6, 8, 7, 3};
        int n = bt.length, wt = 0;
        double total = 0;
        for (int i = 0; i < n - 1; i++)              // sort by burst time
            for (int j = 0; j < n - i - 1; j++)
                if (bt[j] > bt[j + 1]) {
                    int t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                    t = id[j]; id[j] = id[j + 1]; id[j + 1] = t;
                }
        for (int i = 0; i < n; i++) {
            System.out.println("P" + id[i] + " burst = " + bt[i] + ", waiting = " + wt);
            total += wt;
            wt += bt[i];
        }
        System.out.printf("Average waiting time = %.2f%n", total / n);
    }

    // Part B: non-preemptive Priority scheduling (1 = highest priority)
    static void priority() {
        System.out.println("--- Part B: Priority Scheduling ---");
        int[] id = {1, 2, 3, 4, 5}, bt = {10, 1, 2, 1, 5}, pr = {3, 1, 4, 5, 2};
        int n = bt.length, wt = 0;
        double total = 0;
        for (int i = 0; i < n - 1; i++)              // sort by priority
            for (int j = 0; j < n - i - 1; j++)
                if (pr[j] > pr[j + 1]) {
                    int t = pr[j]; pr[j] = pr[j + 1]; pr[j + 1] = t;
                    t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                    t = id[j]; id[j] = id[j + 1]; id[j + 1] = t;
                }
        for (int i = 0; i < n; i++) {
            System.out.println("P" + id[i] + " priority = " + pr[i] + ", waiting = " + wt);
            total += wt;
            wt += bt[i];
        }
        System.out.printf("Average waiting time = %.2f%n", total / n);
    }

    public static void main(String[] args) {
        sjf();
        System.out.println();
        priority();
    }
}
