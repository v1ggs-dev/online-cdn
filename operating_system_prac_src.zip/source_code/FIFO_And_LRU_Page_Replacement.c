#include <stdio.h>

int ref[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};   /* page reference string */
int n = 13, f = 3;                                      /* pages, frames */

void show(int p, int fr[], int hit) {
    printf("Page %d -> %d %d %d  (%s)\n", p, fr[0], fr[1], fr[2], hit ? "hit" : "fault");
}

/* Part A: FIFO - replace the page that came in first */
void fifo() {
    printf("--- Part A: FIFO Page Replacement ---\n");
    int fr[3] = {-1, -1, -1}, next = 0, faults = 0;
    for (int k = 0; k < n; k++) {
        int hit = 0;
        for (int i = 0; i < f; i++) if (fr[i] == ref[k]) hit = 1;
        if (!hit) { fr[next] = ref[k]; next = (next + 1) % f; faults++; }
        show(ref[k], fr, hit);
    }
    printf("Total page faults = %d\n", faults);
}

/* Part B: LRU - replace the page not used for the longest time */
void lru() {
    printf("--- Part B: LRU Page Replacement ---\n");
    int fr[3] = {-1, -1, -1}, last[3] = {0, 0, 0}, faults = 0;
    for (int t = 0; t < n; t++) {
        int hit = -1;
        for (int i = 0; i < f; i++) if (fr[i] == ref[t]) hit = i;
        if (hit >= 0) last[hit] = t;
        else {
            int v = 0;
            for (int i = 0; i < f; i++) {
                if (fr[i] == -1) { v = i; break; }
                if (last[i] < last[v]) v = i;
            }
            fr[v] = ref[t]; last[v] = t; faults++;
        }
        show(ref[t], fr, hit >= 0);
    }
    printf("Total page faults = %d\n", faults);
}

int main() {
    fifo();
    printf("\n");
    lru();
    return 0;
}
