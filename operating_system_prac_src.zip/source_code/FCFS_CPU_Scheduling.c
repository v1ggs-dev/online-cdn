#include <stdio.h>

int bt[] = {5, 8, 12};   /* burst times of P1, P2, P3 */
int n = 3;

/* Part A: FCFS - waiting time of each process */
void waitingTime() {
    printf("--- Part A: FCFS Waiting Time ---\n");
    int wt = 0;
    for (int i = 0; i < n; i++) {
        printf("P%d waiting time = %d\n", i + 1, wt);
        wt += bt[i];
    }
}

/* Part B: FCFS - turnaround time and averages */
void turnaround() {
    printf("--- Part B: FCFS Turnaround Time and Averages ---\n");
    int wt = 0;
    float totalWt = 0, totalTat = 0;
    printf("Process\tBurst\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        int tat = wt + bt[i];
        printf("P%d\t%d\t%d\t%d\n", i + 1, bt[i], wt, tat);
        totalWt += wt;
        totalTat += tat;
        wt += bt[i];
    }
    printf("Average waiting time = %.2f\n", totalWt / n);
    printf("Average turnaround time = %.2f\n", totalTat / n);
}

int main() {
    waitingTime();
    printf("\n");
    turnaround();
    return 0;
}
