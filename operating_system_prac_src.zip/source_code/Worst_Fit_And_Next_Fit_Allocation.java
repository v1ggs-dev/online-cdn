public class Worst_Fit_And_Next_Fit_Allocation {
    static int[] block = {100, 500, 200, 300, 600};   // memory block sizes
    static int[] proc = {212, 417, 112, 426};         // process sizes

    static void print(int i, int pick) {
        if (pick != -1)
            System.out.println("Process " + (i + 1) + " (" + proc[i] + ") -> Block " + (pick + 1));
        else
            System.out.println("Process " + (i + 1) + " (" + proc[i] + ") -> Not allocated");
    }

    // Part A: Worst Fit - largest block that is big enough
    static void worstFit() {
        System.out.println("--- Part A: Worst Fit ---");
        int[] b = block.clone();
        for (int i = 0; i < proc.length; i++) {
            int pick = -1;
            for (int j = 0; j < b.length; j++)
                if (b[j] >= proc[i] && (pick == -1 || b[j] > b[pick])) pick = j;
            if (pick != -1) b[pick] -= proc[i];
            print(i, pick);
        }
    }

    // Part B: Next Fit - like First Fit, but search starts where the last one stopped
    static void nextFit() {
        System.out.println("--- Part B: Next Fit ---");
        int[] b = block.clone();
        int last = 0;
        for (int i = 0; i < proc.length; i++) {
            int pick = -1;
            for (int k = 0; k < b.length; k++) {
                int j = (last + k) % b.length;
                if (b[j] >= proc[i]) { pick = j; break; }
            }
            if (pick != -1) { b[pick] -= proc[i]; last = pick; }
            print(i, pick);
        }
    }

    public static void main(String[] args) {
        worstFit();
        System.out.println();
        nextFit();
    }
}
