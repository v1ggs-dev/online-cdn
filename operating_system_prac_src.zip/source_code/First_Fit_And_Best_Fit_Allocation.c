#include <stdio.h>

int block[] = {100, 500, 200, 300, 600}, nb = 5;   /* memory block sizes */
int proc[] = {212, 417, 112, 426}, np = 4;         /* process sizes */

void print(int i, int pick) {
    if (pick != -1)
        printf("Process %d (%d) -> Block %d\n", i + 1, proc[i], pick + 1);
    else
        printf("Process %d (%d) -> Not allocated\n", i + 1, proc[i]);
}

/* Part A: First Fit - first block that is big enough */
void firstFit() {
    printf("--- Part A: First Fit ---\n");
    int b[5];
    for (int j = 0; j < nb; j++) b[j] = block[j];
    for (int i = 0; i < np; i++) {
        int pick = -1;
        for (int j = 0; j < nb; j++)
            if (b[j] >= proc[i]) { pick = j; break; }
        if (pick != -1) b[pick] -= proc[i];
        print(i, pick);
    }
}

/* Part B: Best Fit - smallest block that is big enough */
void bestFit() {
    printf("--- Part B: Best Fit ---\n");
    int b[5];
    for (int j = 0; j < nb; j++) b[j] = block[j];
    for (int i = 0; i < np; i++) {
        int pick = -1;
        for (int j = 0; j < nb; j++)
            if (b[j] >= proc[i] && (pick == -1 || b[j] < b[pick])) pick = j;
        if (pick != -1) b[pick] -= proc[i];
        print(i, pick);
    }
}

int main() {
    firstFit();
    printf("\n");
    bestFit();
    return 0;
}
