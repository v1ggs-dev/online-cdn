public class FCFS_And_SSTF_Disk_Scheduling {
    static int[] req = {98, 183, 37, 122, 14, 124, 65, 67};   // disk requests
    static int start = 53;                                     // initial head position

    // Part A: FCFS - serve requests in the order they arrive
    static void fcfs() {
        System.out.println("--- Part A: FCFS Disk Scheduling ---");
        int head = start, total = 0;
        for (int r : req) {
            int move = Math.abs(r - head);
            System.out.println(head + " -> " + r + "  (move " + move + ")");
            total += move;
            head = r;
        }
        System.out.println("Total head movement = " + total);
    }

    // Part B: SSTF - always serve the nearest pending request
    static void sstf() {
        System.out.println("--- Part B: SSTF Disk Scheduling ---");
        boolean[] done = new boolean[req.length];
        int head = start, total = 0;
        for (int k = 0; k < req.length; k++) {
            int pick = -1;
            for (int i = 0; i < req.length; i++)
                if (!done[i] && (pick == -1 || Math.abs(req[i] - head) < Math.abs(req[pick] - head)))
                    pick = i;
            int move = Math.abs(req[pick] - head);
            System.out.println(head + " -> " + req[pick] + "  (move " + move + ")");
            total += move;
            head = req[pick];
            done[pick] = true;
        }
        System.out.println("Total head movement = " + total);
    }

    public static void main(String[] args) {
        fcfs();
        System.out.println();
        sstf();
    }
}
