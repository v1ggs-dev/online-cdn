public class First_Fit_And_Best_Fit_Allocation {
    static int[] block = {100, 500, 200, 300, 600};   // memory block sizes
    static int[] proc = {212, 417, 112, 426};         // process sizes

    static void print(int i, int pick) {
        if (pick != -1)
            System.out.println("Process " + (i + 1) + " (" + proc[i] + ") -> Block " + (pick + 1));
        else
            System.out.println("Process " + (i + 1) + " (" + proc[i] + ") -> Not allocated");
    }

    // Part A: First Fit - first block that is big enough
    static void firstFit() {
        System.out.println("--- Part A: First Fit ---");
        int[] b = block.clone();
        for (int i = 0; i < proc.length; i++) {
            int pick = -1;
            for (int j = 0; j < b.length; j++)
                if (b[j] >= proc[i]) { pick = j; break; }
            if (pick != -1) b[pick] -= proc[i];
            print(i, pick);
        }
    }

    // Part B: Best Fit - smallest block that is big enough
    static void bestFit() {
        System.out.println("--- Part B: Best Fit ---");
        int[] b = block.clone();
        for (int i = 0; i < proc.length; i++) {
            int pick = -1;
            for (int j = 0; j < b.length; j++)
                if (b[j] >= proc[i] && (pick == -1 || b[j] < b[pick])) pick = j;
            if (pick != -1) b[pick] -= proc[i];
            print(i, pick);
        }
    }

    public static void main(String[] args) {
        firstFit();
        System.out.println();
        bestFit();
    }
}
