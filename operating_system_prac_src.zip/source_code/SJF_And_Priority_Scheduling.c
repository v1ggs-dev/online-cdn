#include <stdio.h>

/* Part A: non-preemptive SJF (all processes arrive at time 0) */
void sjf() {
    printf("--- Part A: Shortest Job First ---\n");
    int id[] = {1, 2, 3, 4}, bt[] = {6, 8, 7, 3}, n = 4, wt = 0;
    float total = 0;
    for (int i = 0; i < n - 1; i++)              /* sort by burst time */
        for (int j = 0; j < n - i - 1; j++)
            if (bt[j] > bt[j + 1]) {
                int t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                t = id[j]; id[j] = id[j + 1]; id[j + 1] = t;
            }
    for (int i = 0; i < n; i++) {
        printf("P%d burst = %d, waiting = %d\n", id[i], bt[i], wt);
        total += wt;
        wt += bt[i];
    }
    printf("Average waiting time = %.2f\n", total / n);
}

/* Part B: non-preemptive Priority scheduling (1 = highest priority) */
void priority() {
    printf("--- Part B: Priority Scheduling ---\n");
    int id[] = {1, 2, 3, 4, 5}, bt[] = {10, 1, 2, 1, 5}, pr[] = {3, 1, 4, 5, 2};
    int n = 5, wt = 0;
    float total = 0;
    for (int i = 0; i < n - 1; i++)              /* sort by priority */
        for (int j = 0; j < n - i - 1; j++)
            if (pr[j] > pr[j + 1]) {
                int t = pr[j]; pr[j] = pr[j + 1]; pr[j + 1] = t;
                t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                t = id[j]; id[j] = id[j + 1]; id[j + 1] = t;
            }
    for (int i = 0; i < n; i++) {
        printf("P%d priority = %d, waiting = %d\n", id[i], pr[i], wt);
        total += wt;
        wt += bt[i];
    }
    printf("Average waiting time = %.2f\n", total / n);
}

int main() {
    sjf();
    printf("\n");
    priority();
    return 0;
}
