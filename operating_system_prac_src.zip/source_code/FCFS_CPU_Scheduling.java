public class FCFS_CPU_Scheduling {
    static int[] bt = {5, 8, 12};   // burst times of P1, P2, P3

    // Part A: FCFS - waiting time of each process
    static void waitingTime() {
        System.out.println("--- Part A: FCFS Waiting Time ---");
        int wt = 0;
        for (int i = 0; i < bt.length; i++) {
            System.out.println("P" + (i + 1) + " waiting time = " + wt);
            wt += bt[i];
        }
    }

    // Part B: FCFS - turnaround time and averages
    static void turnaround() {
        System.out.println("--- Part B: FCFS Turnaround Time and Averages ---");
        int n = bt.length, wt = 0;
        double totalWt = 0, totalTat = 0;
        System.out.println("Process\tBurst\tWaiting\tTurnaround");
        for (int i = 0; i < n; i++) {
            int tat = wt + bt[i];
            System.out.println("P" + (i + 1) + "\t" + bt[i] + "\t" + wt + "\t" + tat);
            totalWt += wt;
            totalTat += tat;
            wt += bt[i];
        }
        System.out.printf("Average waiting time = %.2f%n", totalWt / n);
        System.out.printf("Average turnaround time = %.2f%n", totalTat / n);
    }

    public static void main(String[] args) {
        waitingTime();
        System.out.println();
        turnaround();
    }
}
